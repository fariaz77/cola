from database import db

class Livros(db.Model):
    ibsn = db.Column(db. integer , primary_key=True)
    titulo = db.Column(db. string(1000), nullblale=False)
    datapubli = db.Column(db. date)
    npag= db. Column(db. Integer)
    autor= db.Column(db. string(1000), nullblale=False)
    categoria= db. Column9db. String(15)

class Autor (db. model):
    nome = db.Column(db.string(80), nullblable=False)
    datanasc = db.column(db.Date)
    nacionalidade = db.column(db.string(80))