from flask import *

livrariaController = Blueprint ('livraria', __name__)

@livrariaController.route('/')
def inicio():
    return render_template('index.html')